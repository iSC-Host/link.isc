module.exports = [
	{
		id: '1',
		task: 'get bananas',
		category: 'shopping',
		due: '',
		starred: false
	},
	{
		id: '2',
		task: 'call Erin',
		category: 'home',
		due: '',
		starred: false
	},
	{
		id: '3',
		task: 'finish taasky demo',
		category: 'work',
		due: 'Fri, March 7',
		starred: false
	},
	{
		id: '4',
		task: 'Railroad Earth concert',
		category: 'friends',
		due: 'Thur, March 13',
		starred: false
	},
	{
		id: '5',
		task: 'clean house',
		category: 'home',
		due: '',
		starred: false
	},
	{
		id: '6',
		task: 'surfing with Justin',
		category: 'friends',
		due: 'Sat, March 15',
		starred: false
	},
	{
		id: '7',
		task: 'get more bananas',
		category: 'shopping',
		due: '',
		starred: false
	},
];