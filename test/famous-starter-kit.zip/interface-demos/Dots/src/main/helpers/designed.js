define(function(require, exports, module) {

    // Size this application was originally designed for
    var designed = {
        width:  320,
        height: 548,
    };

    module.exports = designed;

});



